﻿
namespace bingo_bingo
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBetNuber1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBet = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLottoNumbers = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblBetNumber = new System.Windows.Forms.Label();
            this.btnBet10 = new System.Windows.Forms.Button();
            this.btnSingle = new System.Windows.Forms.Button();
            this.btnBig = new System.Windows.Forms.Button();
            this.btnBet9 = new System.Windows.Forms.Button();
            this.btnBet8 = new System.Windows.Forms.Button();
            this.btnSmall = new System.Windows.Forms.Button();
            this.btnEven = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnLottery = new System.Windows.Forms.Button();
            this.lblWinning = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBetNuber2 = new System.Windows.Forms.TextBox();
            this.txtBetNuber3 = new System.Windows.Forms.TextBox();
            this.txtBetNuber4 = new System.Windows.Forms.TextBox();
            this.txtBetNuber5 = new System.Windows.Forms.TextBox();
            this.txtBetNuber6 = new System.Windows.Forms.TextBox();
            this.txtBetNuber7 = new System.Windows.Forms.TextBox();
            this.txtBetNuber8 = new System.Windows.Forms.TextBox();
            this.txtBetNuber9 = new System.Windows.Forms.TextBox();
            this.txtBetNuber10 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtBetNuber1
            // 
            this.txtBetNuber1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber1.Location = new System.Drawing.Point(12, 225);
            this.txtBetNuber1.MaxLength = 2;
            this.txtBetNuber1.Name = "txtBetNuber1";
            this.txtBetNuber1.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber1.TabIndex = 0;
            this.txtBetNuber1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(113, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Bingo Bingo";
            // 
            // btnBet
            // 
            this.btnBet.Enabled = false;
            this.btnBet.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBet.Location = new System.Drawing.Point(157, 263);
            this.btnBet.Name = "btnBet";
            this.btnBet.Size = new System.Drawing.Size(97, 27);
            this.btnBet.TabIndex = 2;
            this.btnBet.Text = "投注號碼輸入";
            this.btnBet.UseVisualStyleBackColor = true;
            this.btnBet.Click += new System.EventHandler(this.btnBet_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(17, 342);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "開獎號碼";
            // 
            // lblLottoNumbers
            // 
            this.lblLottoNumbers.BackColor = System.Drawing.Color.White;
            this.lblLottoNumbers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLottoNumbers.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblLottoNumbers.Location = new System.Drawing.Point(12, 366);
            this.lblLottoNumbers.Name = "lblLottoNumbers";
            this.lblLottoNumbers.Size = new System.Drawing.Size(291, 50);
            this.lblLottoNumbers.TabIndex = 4;
            this.lblLottoNumbers.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(17, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "投注號碼";
            // 
            // lblBetNumber
            // 
            this.lblBetNumber.BackColor = System.Drawing.Color.White;
            this.lblBetNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBetNumber.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblBetNumber.Location = new System.Drawing.Point(12, 317);
            this.lblBetNumber.Name = "lblBetNumber";
            this.lblBetNumber.Size = new System.Drawing.Size(291, 25);
            this.lblBetNumber.TabIndex = 6;
            this.lblBetNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnBet10
            // 
            this.btnBet10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBet10.Location = new System.Drawing.Point(22, 105);
            this.btnBet10.Name = "btnBet10";
            this.btnBet10.Size = new System.Drawing.Size(53, 27);
            this.btnBet10.TabIndex = 7;
            this.btnBet10.Text = "十星";
            this.btnBet10.UseVisualStyleBackColor = true;
            this.btnBet10.Click += new System.EventHandler(this.btnBet10_Click);
            // 
            // btnSingle
            // 
            this.btnSingle.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSingle.Location = new System.Drawing.Point(340, 105);
            this.btnSingle.Name = "btnSingle";
            this.btnSingle.Size = new System.Drawing.Size(53, 27);
            this.btnSingle.TabIndex = 9;
            this.btnSingle.Text = "單";
            this.btnSingle.UseVisualStyleBackColor = true;
            this.btnSingle.Click += new System.EventHandler(this.btnSingle_Click);
            // 
            // btnBig
            // 
            this.btnBig.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBig.Location = new System.Drawing.Point(183, 171);
            this.btnBig.Name = "btnBig";
            this.btnBig.Size = new System.Drawing.Size(53, 27);
            this.btnBig.TabIndex = 10;
            this.btnBig.Text = "大";
            this.btnBig.UseVisualStyleBackColor = true;
            this.btnBig.Click += new System.EventHandler(this.btnBig_Click);
            // 
            // btnBet9
            // 
            this.btnBet9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBet9.Location = new System.Drawing.Point(22, 138);
            this.btnBet9.Name = "btnBet9";
            this.btnBet9.Size = new System.Drawing.Size(53, 27);
            this.btnBet9.TabIndex = 11;
            this.btnBet9.Text = "九星";
            this.btnBet9.UseVisualStyleBackColor = true;
            this.btnBet9.Click += new System.EventHandler(this.btnBet9_Click);
            // 
            // btnBet8
            // 
            this.btnBet8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnBet8.Location = new System.Drawing.Point(22, 171);
            this.btnBet8.Name = "btnBet8";
            this.btnBet8.Size = new System.Drawing.Size(53, 27);
            this.btnBet8.TabIndex = 12;
            this.btnBet8.Text = "八星";
            this.btnBet8.UseVisualStyleBackColor = true;
            this.btnBet8.Click += new System.EventHandler(this.btnBet8_Click);
            // 
            // btnSmall
            // 
            this.btnSmall.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSmall.Location = new System.Drawing.Point(183, 105);
            this.btnSmall.Name = "btnSmall";
            this.btnSmall.Size = new System.Drawing.Size(53, 27);
            this.btnSmall.TabIndex = 13;
            this.btnSmall.Text = "小";
            this.btnSmall.UseVisualStyleBackColor = true;
            this.btnSmall.Click += new System.EventHandler(this.btnSmall_Click);
            // 
            // btnEven
            // 
            this.btnEven.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnEven.Location = new System.Drawing.Point(340, 171);
            this.btnEven.Name = "btnEven";
            this.btnEven.Size = new System.Drawing.Size(53, 27);
            this.btnEven.TabIndex = 14;
            this.btnEven.Text = "雙";
            this.btnEven.UseVisualStyleBackColor = true;
            this.btnEven.Click += new System.EventHandler(this.btnEven_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(13, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 24);
            this.label7.TabIndex = 15;
            this.label7.Text = "基本玩法";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(335, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 24);
            this.label8.TabIndex = 16;
            this.label8.Text = "猜單雙";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(177, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 24);
            this.label9.TabIndex = 17;
            this.label9.Text = "比大小";
            // 
            // btnLottery
            // 
            this.btnLottery.Enabled = false;
            this.btnLottery.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnLottery.Location = new System.Drawing.Point(324, 317);
            this.btnLottery.Name = "btnLottery";
            this.btnLottery.Size = new System.Drawing.Size(80, 99);
            this.btnLottery.TabIndex = 18;
            this.btnLottery.Text = "開獎";
            this.btnLottery.UseVisualStyleBackColor = true;
            this.btnLottery.Click += new System.EventHandler(this.btnLottery_Click);
            // 
            // lblWinning
            // 
            this.lblWinning.BackColor = System.Drawing.Color.White;
            this.lblWinning.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWinning.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblWinning.Location = new System.Drawing.Point(12, 440);
            this.lblWinning.Name = "lblWinning";
            this.lblWinning.Size = new System.Drawing.Size(392, 222);
            this.lblWinning.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(17, 416);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 24);
            this.label5.TabIndex = 21;
            this.label5.Text = "中獎訊息";
            // 
            // txtBetNuber2
            // 
            this.txtBetNuber2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber2.Location = new System.Drawing.Point(52, 225);
            this.txtBetNuber2.MaxLength = 2;
            this.txtBetNuber2.Name = "txtBetNuber2";
            this.txtBetNuber2.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber2.TabIndex = 22;
            this.txtBetNuber2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber3
            // 
            this.txtBetNuber3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber3.Location = new System.Drawing.Point(92, 225);
            this.txtBetNuber3.MaxLength = 2;
            this.txtBetNuber3.Name = "txtBetNuber3";
            this.txtBetNuber3.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber3.TabIndex = 23;
            this.txtBetNuber3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber4
            // 
            this.txtBetNuber4.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber4.Location = new System.Drawing.Point(132, 225);
            this.txtBetNuber4.MaxLength = 2;
            this.txtBetNuber4.Name = "txtBetNuber4";
            this.txtBetNuber4.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber4.TabIndex = 24;
            this.txtBetNuber4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber5
            // 
            this.txtBetNuber5.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber5.Location = new System.Drawing.Point(172, 225);
            this.txtBetNuber5.MaxLength = 2;
            this.txtBetNuber5.Name = "txtBetNuber5";
            this.txtBetNuber5.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber5.TabIndex = 25;
            this.txtBetNuber5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber6
            // 
            this.txtBetNuber6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber6.Location = new System.Drawing.Point(212, 225);
            this.txtBetNuber6.MaxLength = 2;
            this.txtBetNuber6.Name = "txtBetNuber6";
            this.txtBetNuber6.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber6.TabIndex = 26;
            this.txtBetNuber6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber7
            // 
            this.txtBetNuber7.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber7.Location = new System.Drawing.Point(252, 225);
            this.txtBetNuber7.MaxLength = 2;
            this.txtBetNuber7.Name = "txtBetNuber7";
            this.txtBetNuber7.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber7.TabIndex = 27;
            this.txtBetNuber7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber8
            // 
            this.txtBetNuber8.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber8.Location = new System.Drawing.Point(292, 225);
            this.txtBetNuber8.MaxLength = 2;
            this.txtBetNuber8.Name = "txtBetNuber8";
            this.txtBetNuber8.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber8.TabIndex = 28;
            this.txtBetNuber8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber9
            // 
            this.txtBetNuber9.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber9.Location = new System.Drawing.Point(332, 225);
            this.txtBetNuber9.MaxLength = 2;
            this.txtBetNuber9.Name = "txtBetNuber9";
            this.txtBetNuber9.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber9.TabIndex = 29;
            this.txtBetNuber9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBetNuber10
            // 
            this.txtBetNuber10.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtBetNuber10.Location = new System.Drawing.Point(372, 225);
            this.txtBetNuber10.MaxLength = 2;
            this.txtBetNuber10.Name = "txtBetNuber10";
            this.txtBetNuber10.Size = new System.Drawing.Size(34, 29);
            this.txtBetNuber10.TabIndex = 30;
            this.txtBetNuber10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(414, 671);
            this.Controls.Add(this.txtBetNuber10);
            this.Controls.Add(this.txtBetNuber1);
            this.Controls.Add(this.txtBetNuber9);
            this.Controls.Add(this.btnLottery);
            this.Controls.Add(this.txtBetNuber2);
            this.Controls.Add(this.btnEven);
            this.Controls.Add(this.txtBetNuber8);
            this.Controls.Add(this.btnSmall);
            this.Controls.Add(this.txtBetNuber3);
            this.Controls.Add(this.btnBet8);
            this.Controls.Add(this.txtBetNuber7);
            this.Controls.Add(this.btnBet9);
            this.Controls.Add(this.txtBetNuber4);
            this.Controls.Add(this.btnBig);
            this.Controls.Add(this.txtBetNuber6);
            this.Controls.Add(this.btnSingle);
            this.Controls.Add(this.txtBetNuber5);
            this.Controls.Add(this.btnBet10);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblWinning);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblBetNumber);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblLottoNumbers);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBet);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Bingo Bingo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBetNuber1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLottoNumbers;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblBetNumber;
        private System.Windows.Forms.Button btnBet10;
        private System.Windows.Forms.Button btnSingle;
        private System.Windows.Forms.Button btnBig;
        private System.Windows.Forms.Button btnBet9;
        private System.Windows.Forms.Button btnBet8;
        private System.Windows.Forms.Button btnSmall;
        private System.Windows.Forms.Button btnEven;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnLottery;
        private System.Windows.Forms.Label lblWinning;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBetNuber2;
        private System.Windows.Forms.TextBox txtBetNuber3;
        private System.Windows.Forms.TextBox txtBetNuber4;
        private System.Windows.Forms.TextBox txtBetNuber5;
        private System.Windows.Forms.TextBox txtBetNuber6;
        private System.Windows.Forms.TextBox txtBetNuber7;
        private System.Windows.Forms.TextBox txtBetNuber8;
        private System.Windows.Forms.TextBox txtBetNuber9;
        private System.Windows.Forms.TextBox txtBetNuber10;
    }
}

